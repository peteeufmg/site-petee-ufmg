
var myHeading = document.querySelector('#bemVindo');

var my_button1 = document.getElementById('mudaCor')
my_button1.onclick = function(){
	var myColor = prompt('Digite a nova cor:')
	myHeading.style.color = myColor;
}

var my_button2 = document.getElementById('mudaNome')
my_button2.onclick = function(){
	var myName = prompt('Digite o seu nome:')
	myHeading.textContent = 'Bem vindo, ' + myName;
}