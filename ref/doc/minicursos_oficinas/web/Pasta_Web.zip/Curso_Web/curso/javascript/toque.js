var myHtml = document.querySelector('html')
myHtml.onclick = function () {
	alert('');
}