$(function(){
	$("p").click(function(){
		$(this).hide();
	});
});
