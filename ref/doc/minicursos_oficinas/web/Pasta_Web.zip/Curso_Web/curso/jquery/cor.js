$(function(){
	$('button').click(function(){
		$('h1').css('color', 'red');
	});
});
