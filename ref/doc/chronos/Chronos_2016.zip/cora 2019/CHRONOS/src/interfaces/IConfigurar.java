package interfaces;

public interface IConfigurar {
    public void lookandfeel();
    
    public void parametros();
    
    public void criarArquivoParametros();
    
    public void salvarParametros(); 
}
